# Rust micro OS kernel

This project is written under the instruction of [Writing an OS in Rust](https://os.phil-opp.com/)

## TODO
- [ ] add test to interrupt handlers
